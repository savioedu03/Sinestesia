# Leitor TTS

App Android que gera o audio da leitura em arquivos (motor de voz do Android), toca em ate 4x mantendo o tom da voz, e mostra uma palavra por vez no centro da tela com cor por classe gramatical (banco de palavras pessoal).

Acima de 4x: leitura so visual (sem audio), ate 20x.

O APK e gerado pelo GitHub Actions (aba Actions > Build APK > Artifacts).
