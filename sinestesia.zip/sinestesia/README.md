# Sinestesia

App Android de leitura: gera o audio com o motor de voz do Android, toca acelerado mantendo o tom, e mostra uma palavra por vez no centro da tela, com cor por classe gramatical (banco de palavras pessoal).

O APK e gerado pelo GitHub Actions (aba Actions > Build APK > Artifacts).
